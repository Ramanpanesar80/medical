package October;
class Mytests {

	 private WebDriver driver;

	    @BeforeEach
	    void setUp() {
	        // Initialize WebDriver before each test
	        driver = new ChromeDriver();
	    }

	    @AfterEach
	    void tearDown() {
	        // Cleanup after each test
	        if (driver != null) {
	            driver.quit();
	        }
	    }

	    private void loadHomePage() {
	        driver.get("file:///Users/pargol/Desktop/lab/Index.html");  // Update to use a file URI
	    }

    @Test
    void testTitle() {
        loadHomePage();
        String expectedTitle = "Company Website";
        String actualTitle = driver.getTitle();
        assertEquals(expectedTitle, actualTitle, "The page title should match");
    }