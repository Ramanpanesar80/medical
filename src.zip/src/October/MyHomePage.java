package October;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static org.junit.Assert.*;

import java.time.Duration;

public class MyHomePage {

    private WebDriver driver;

    @Before
    public void setUp() {
       
        driver = new ChromeDriver();
        driver.get("http://localhost:3000");  
    }
    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit(); 
        }
    }

    @Test
   public void testPageTitle() {
       String expectedTitle = "React App";
        String actualTitle = driver.getTitle();
       assertEquals("Page title should be correct", expectedTitle, actualTitle);
    }

    @Test
    public void testHome() {
       
         WebElement homeLink = driver.findElement(By.xpath("/html/body/div/div/div/nav/ul/li[1]/a"));
         assertNotNull("Home link should exist", homeLink);
        
         }
    @Test 
    public void testaboutLinks() {
      WebElement aboutUsLink = driver.findElement(By.xpath("/html/body/div/div/div/nav/ul/li[2]/a"));
      aboutUsLink.click();
      assertNotNull("About Us link should exist", aboutUsLink);
    }
  @Test
    public void testServices() {

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        
        WebElement aboutUsLink = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/div/div/nav/ul/li[3]/a")));
        aboutUsLink.click();

       
        String expectedUrl = "http://localhost:3000/services"; 
        wait.until(ExpectedConditions.urlToBe(expectedUrl));

       
        assertNotEquals(expectedUrl, driver.getCurrentUrl(), "Redirection to 'About Us' page failed from Doctor Dashboard.");
    }

@Test
public void testContact() {

    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

    
    WebElement aboutUsLink = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/div/div/nav/ul/li[4]/a")));
    aboutUsLink.click();

   
    String expectedUrl = "http://localhost:3000/contact"; 
    wait.until(ExpectedConditions.urlToBe(expectedUrl));

    
    assertNotEquals(expectedUrl, driver.getCurrentUrl(), "Redirection to 'About Us' page failed from Doctor Dashboard.");
}

   

       
    @Test
  public void testSignin() {
  WebElement signinLink = driver.findElement(By.xpath("/html/body/div/div/div/nav/div[2]/a[1]"));
    
  assertNotNull("Signin link should exist", signinLink);
  
    }
@Test
public void testSignup() {
WebElement signupLink = driver.findElement(By.xpath("/html/body/div/div/div/nav/div[2]/a[2]"));
signupLink.click();
assertNotNull("Signup link should exist", signupLink);

  }

    @Test
    public void testMainHeading() {
       
        WebElement heading = driver.findElement(By.xpath("/html/body/div/div/div/div/h1"));
        assertNotNull("Main heading should be present", heading);
       
    }
    @Test
  public void testh3Heading() {
     
      WebElement heading = driver.findElement(By.xpath("/html/body/div/div/div/div/p"));
      assertNotNull("h3 heading should be present", heading);
     
  }
  @Test
  public void testBookingappointment() {
  WebElement bookingappointmentLink = driver.findElement(By.xpath("/html/body/div/div/div/nav/div[2]/a[2]"));
  assertNotNull("Bookingappointment link should exist", bookingappointmentLink);
  
    }
 
 
    @Test
    public void testAboutUs() {

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        
        WebElement aboutUsLink = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/div/footer/div/ul/li[1]/a")));
        aboutUsLink.click();

       
        String expectedUrl = "http://localhost:3000/about"; 
        wait.until(ExpectedConditions.urlToBe(expectedUrl));

      
        assertNotEquals(expectedUrl, driver.getCurrentUrl(), "Redirection to 'About Us' page failed from Doctor Dashboard.");
    }

@Test
public void testprivacypolicy() {

    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

    
    WebElement aboutUsLink = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/div/footer/div/ul/li[2]/a")));
    aboutUsLink.click();

 
    String expectedUrl = "http://localhost:3000/privacy-policy"; 
    wait.until(ExpectedConditions.urlToBe(expectedUrl));

    
    assertNotEquals(expectedUrl, driver.getCurrentUrl(), "Redirection to 'About Us' page failed from Doctor Dashboard.");
}
@Test
public void testTermsandConditions() {

    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

    
    WebElement aboutUsLink = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/div/footer/div/ul/li[3]/a")));
    aboutUsLink.click();

    
    String expectedUrl = "http://localhost:3000/terms-and-conditions"; 
    wait.until(ExpectedConditions.urlToBe(expectedUrl));

    
    assertNotEquals(expectedUrl, driver.getCurrentUrl(), "Redirection to 'About Us' page failed from Doctor Dashboard.");
}
        
      

    @Test
    public void testFooterText() {
        
        WebElement footerText = driver.findElement(By.xpath("/html/body/div/div/footer/div/p"));
        assertNotNull("Footer text should be present", footerText);
        assertTrue("Footer should contain the correct copyright text", footerText.getText().contains("© 2024 Medical Appointment System. All Rights Reserved."));
    }
}
//  
//}
